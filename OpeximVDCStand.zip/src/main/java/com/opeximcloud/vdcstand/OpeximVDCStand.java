package com.opeximcloud.vdcstand;

import org.bukkit.Bukkit;
import org.bukkit.entity.ArmorStand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class OpeximVDCStand extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Opexim VDC Stand enabled!");
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof ArmorStand stand) {
            if (stand.getScoreboardTags().contains("ProtectedAS")) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof ArmorStand stand) {
            if (stand.getScoreboardTags().contains("ProtectedAS")) {
                e.setCancelled(true);
                stand.setHealth(20.0);
            }
        }
    }

    @EventHandler
    public void onKillCommand(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof ArmorStand stand) {
            if (stand.getScoreboardTags().contains("ProtectedAS")) {
                e.setCancelled(true);
            }
        }
    }
}
